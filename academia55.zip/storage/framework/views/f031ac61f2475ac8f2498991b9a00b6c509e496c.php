<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-xs-12 col-sm-3 col-md-3">
        <div class="panel widget center bgimage" style="margin-bottom:0;overflow:hidden;background-color: #343C46;">
            <!-- <div class="dimmer"></div> -->
            <div class="panel-content">
                <i class='voyager-group'></i>
                <!-- <h4>Usuarios</h4> -->
                <!--    <p></p> -->
                <a href="<?php echo e(route('voyager.users.index')); ?>" class="btn btn-primary btn-lg">Usuarios</a>
            </div>
        </div>
    </div>

    <div class="col-xs-12 col-sm-3 col-md-3">
        <div class="panel widget center bgimage" style="margin-bottom:0;overflow:hidden;background-color: #343C46;;">
            <!-- <div class="dimmer"></div> -->
            <div class="panel-content">
                <i class='voyager-settings'></i>
                <!-- <h4>Usuarios</h4> -->
                <!--    <p></p> -->
                <a href="<?php echo e(route('voyager.roles.index')); ?>" class="btn btn-primary btn-lg">Roles</a>
            </div>
        </div>
    </div>

    <div class="col-xs-12 col-sm-3 col-md-3">
        <div class="panel widget center bgimage" style="margin-bottom:0;overflow:hidden;background-color: #343C46;">
            <!-- <div class="dimer"></div> -->
            <div class="panel-content">
                <i class='voyager-wand'></i>
                <!-- <h4>Usuarios</h4> -->
                <!--    <p></p> -->
                <a href="<?php echo e(route('voyager.permissions.index')); ?>" class="btn btn-primary btn-lg">Permisos</a>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>