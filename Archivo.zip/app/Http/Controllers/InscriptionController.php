<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class InscriptionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index()
    {
        //return 'hola';
        return view('inscription.index');
    }
    public function control_index()
    {   
        $inscripciones = DB::table('inscripciones')
                            ->join('estudiantes','estudiantes.id', '=','inscripciones.estudiante_id')
                            ->join('carreras','carreras.id', '=','inscripciones.carrera_id')
                            ->join('horarios','horarios.id', '=','inscripciones.tipo_id')
                            ->join('tipos','tipos.id', '=','inscripciones.horario_id')
                            ->select('inscripciones.*', 'estudiantes.num_documento', 'estudiantes.nombres', 'estudiantes.apellidos_paterno', 'estudiantes.apellidos_materno', 'carreras.nombre as carrera','horarios.nombre as horario','tipos.nombre as tipo','estudiantes.id as estudiante_id')
                            ->OrderBy('inscripciones.created_at','desc')
                            ->paginate(6);
                            
            $total = DB::table('inscripciones')
                            ->join('estudiantes','estudiantes.id', '=','inscripciones.estudiante_id')
                            ->join('carreras','carreras.id', '=','inscripciones.carrera_id')
                            ->join('horarios','horarios.id', '=','inscripciones.tipo_id')
                            ->join('tipos','tipos.id', '=','inscripciones.horario_id')
                            ->count();

            $suma = DB::table('inscripciones')
                            ->join('estudiantes','estudiantes.id', '=','inscripciones.estudiante_id')
                            ->join('carreras','carreras.id', '=','inscripciones.carrera_id')
                            ->join('horarios','horarios.id', '=','inscripciones.tipo_id')
                            ->join('tipos','tipos.id', '=','inscripciones.horario_id')
                            //->select('inscripciones.monto')
                            ->sum('inscripciones.monto');
            //return $suma;

            $filtro = '';
            $criterio ='';
            //return dd($inscripciones);
            return view('inscription.control_index',compact('inscripciones','criterio','filtro','total','suma'));
        
    }   

    public function control_create()
    {
        $carreras = DB::table('carreras')->get();
        $horarios = DB::table('horarios')->where('habilitado',true)->get();
        $sexos = DB::table('sexualidades')->get();
        $docs = DB::table('documentos')->get();
        $tipos = DB::table('tipos')->get();
        return view('inscription.control_create',compact('carreras','horarios','sexos','docs','tipos'));
    }
    public function control_storage(Request $request)
    {
        //return dd($request);
        $aux_cuota = $request->estado ? true : false; 

       //return dd($aux_cuota);
        //Estudiante
        $estudiante = Estudiante::create([
        'nombres' => $request->nombres,
        'apellidos_paterno' => $request->apellidos_paterno,
        'apellidos_materno' => $request->apellidos_materno,
        'documento_id' => 1,
        'num_documento' => $request->num_documento.' '.$request->expedido,
        'telefono' => $request->telefono,
        'telefono2' => $request->telefono2,
        'direccion' => $request->direccion,
        'user_id' => Auth::user()->id,
        'sexualidad_id' => $request->sexualidad_id
         ]);

         $estudiante = "";
        
        //Inscripciones
        $insc = Inscripcione::create([
        'fecha_insc' => Carbon::now(),
        'user_id' => Auth::user()->id,
        'carrera_id' => $request->carrera_id,
        'horario_id' => $request->horario_id,
        'fecha_inicio' => $request->fecha_inicio,
        'observaciones' => $request->observaciones,
        'estudiante_id' => $estudiante->id,
        'monto' =>  $request->monto_fijo,
        'tipo_id' => $request->tipo_id
        ]);

        //Recibo
        $num_recibo = DB::table('recibos')->count()+1;
        $num_recibo = str_pad($num_recibo,6,'0',STR_PAD_LEFT).'/'.Carbon::now()->year;
        $recibo = $recibo = Recibo::create([
        'fecha' => Carbon::now(),
        'numero' => $num_recibo,
        'concepto' => $request->observaciones,
        'user_id' => Auth::user()->id,
        'monto_numeral' => $request->monto, 
        'monto_literal' => NumerosEnLetras::convertir($request->monto, 'Bolivianos',true),
        'estudiante_id' => $estudiante->id
        ]);

        //Mensualidad
        $mens = Mensualidade::create([
        'num_mens' => 1,
        'fecha_pago' => Carbon::now(),
        'monto' => $request->monto,
        'fecha_inicio' => $request->fecha_inicio,
        'fecha_final' => Carbon::parse($request->fecha_inicio)->addMonth(),
        'user_id' => Auth::user()->id,
        'inscripcion_id' => $insc->id,
        'observaciones' => $request->observaciones,
        'estado' => $request->estado ? true : false,
        'recibo_id' => $recibo->id
        ]);

        //Pago
        if($aux_cuota)
        {
            
        }else
        {
             Pago::create([
                'fecha_pago' => Carbon::now(),
                'mensualidad_id' =>$mens->id,
                'user_id' => Auth::user()->id,
                'monto' => $request->monto,
                'observaciones' => $request->observaciones,
                'recibo_id' => $recibo->id
                ]);
        
        }

        //$this->boleta($insc);
        return redirect()->route('mensualidades_mi.show',$insc->id)->with(['message' => "Inscripción realizada correctamente", 'alert-type' => 'info']);
    }
}
