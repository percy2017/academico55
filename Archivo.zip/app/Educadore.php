<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Educadore extends Model
{
    //
}
